% Applications personelles - Guillaume Plateau

% Sphere
% function z=costfunc(v);
% if ~isempty(v)
%     z = sum(v.^2,1);
% else
% 	z=[];
% end
% end

% Multiple optima
function z=costfunc(v);
if ~isempty(v)
    p1=sin(2*v(1,:)+3*v(2,:));
    p2=cos(3*v(1,:)-5*v(2,:));
    p3=sin(v(1,:)-2*v(2,:));
    p4=sin(v(1,:)+3*v(2,:));
    z = -(p1-p2-p3+p4);
else
	z=[];
end
end


