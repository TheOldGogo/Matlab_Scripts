% Plot the multi-optima function
clear all;
% clf;
clc;

% function [pos,best,cost,ev_c,ev_p,X,Y,Z]=mvopt(perc);

minx=-2;
maxx=3;
miny=-3;
maxy=1;
step=0.05;

xvect=minx:step:maxx;
yvect=miny:step:maxy;

[X,Y] = meshgrid(xvect,yvect);

p1=sin(2*X+3*Y);
p2=cos(3*X-5*Y);
p3=sin(X-2*Y);
p4=sin(X+3*Y);
Z = p1-p2-p3+p4;

[best,cost,nbiter,dur,ev_c,ev_p]=...
    lcs(50,0.2,3.5,0,2,[-2,3;-3,1],[],-Inf,20,Inf,'max');

% figure;
% surf(X,Y,Z,'FaceColor','interp','EdgeColor','none')
% surf(X,Y,Z,'FaceColor','interp','EdgeColor','none',...
%     'FaceLighting','phong')
% camlight right
% view(-44,74)
% hold on;
% plot3([X(38),X(67)],[Y(38),Y(67)],[Z(38),Z(67)],'.r','MarkerSize',20);
% hold off;

mov = avifile(strcat(pwd,'/movie01'),'quality',25,'fps',10);
hfig=figure;
for i=1:size(ev_c,1)
    surf(X,Y,Z,'FaceColor','interp','EdgeColor','none');
%     surf(X,Y,Z,'FaceColor','interp','EdgeColor','none',...
%         'FaceLighting','phong');
    title(['Population after ',num2str(i-1),' mutations'],'fontsize',14);
    camlight right;
    view(-15,70);
    view(-44,74);
    hold on;
    plot3(ev_p(1,:,i),ev_p(2,:,i),ev_c(i,:),'.b','MarkerSize',25);
    hold off;
    uiwait(hfig,1);
    F = getframe(gcf);
    mov = addframe(mov,F);
end
mov = close(mov);

best
cost
perc=0.05;
pos = fopt(cost,perc)
sortc = zeros(size(pos));
sortc(find(pos)) = cost(pos(find(pos)))

nvar=2;
bests=zeros(nvar,size(pos,2),size(pos,1));
for i=1:size(pos,1)
tmp=best(:,pos(i,find(pos(i,:))));
bests(:,:,i)=[tmp,zeros(nvar,(size(pos,2)-size(find(pos(i,:)),2)))];
end
bests

% end









