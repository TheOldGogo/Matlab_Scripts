% After using lcs, use fopt to identify the different optima
% within a precision that you give (in percent)

function [pos]=fopt(cost,perc);

loc=1:size(cost,2);
kpg=1;
pos=[];
while kpg==1
    cond=abs((cost(1,loc)-cost(1,loc(1)))/cost(1,loc(1)));
    tmp=find(cond<perc);
    pos(size(pos,1)+1,1:size(tmp,2))=loc(tmp);
    loc(tmp)=[];
    if isempty(loc)
        kpg=0;
        break
    end
end

end






