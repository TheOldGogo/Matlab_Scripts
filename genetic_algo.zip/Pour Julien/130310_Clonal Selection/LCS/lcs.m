% Selection Clonale
% G. Plateau
% Oct. 12th 2007

% implementation Scilab : d'apres Plateau, Gorenflot, Avis, Projet 2A...
%     ENSPS 2005
% algorithme : d'apres Leanardo N. de Castro, J. Von Zuben,
% Learning and Optimization Using the Clonal Selection Principle
% IEEE Transactions on Evolutionary Computation Vol. 6 No. 3, Juin 2002,...
%     pages 239-251

% NB : lcs MINIMISE la fonction costfunc(x)

% version 'globale' -> recherche de l'optimum global 
function [best,cost,nbiter,dur,ev_c,ev_p]=lcs(N,be,ro,d,...
    nvar,span,init,tol,itmax,durmax,typeopt)

% Parametres internes au programme (lies a la fonction utilisee)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%N;		        % nombre de valeurs initiales
%L;		        % largeur du domaine a etudier
%C;             % coin gauche du domaine a etudier
%be;            % facteur multiplicatif (be > 1/N)
%ro;            % facteur de decroissance (ro >= 1), calcul du taux de...
%                 lcs_mutation
%d;             % nombre de nouveaux elements aleatoires (0 <= d < N)
%typeopt        % type d'optimisation ('min' ou 'max')

%valeurs "optimales" proposees par le groupe Projet ENSPS pour certaines...
%     fonctions test
%sphere     : N=10; be=1; ro=25;    d=0;
%DeJongf2   : N=10; be=1; ro=33;    d=1;
%DeJongf4   : N=10; be=1; ro=0.001; d=0;
%Shaffer    : N=10; be=1; ro=40;    d=1;
%Rosenbrock : N=10; be=1; ro=5;     d=1;
%Griewank   : N=10; be=1; ro=1;     d=2;
%Rastrigin  : N=10; be=1; ro=0.005; d=0;

% Parametres d'entree de la fonction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%nvar;       % dimension des vecteurs d'entree -> element variable
%span;       % matrice a deux colonnes dont la ligne 'i' definit...
%              l'intervalle de recherche concernant la nvarension 'i'
%init;       % vecteur (nvar,1) optionnel, valeurs initiales...
%              si [], initialisation par v.a. uniforme 
%tol;	     % seuil de convergence sur la valeur de costfunc
%itmax;      % nombre de cycle ou nombre de populations generees
%durmax;     % dur�e maximale autorisee pour l'optimisation

% Parametres de sortie de la fonction
%%%%%%%%%%%%%%%%%%%%
%dur;        % temps de calcul necessaire pour fournir le resultat
%best;       % position du meilleur anti-corps
%cost;       % cout associe au meilleur anti-corps
%nbiter;     % nombre d'iterations de la boucle principale effectuees


% Reglages par defaut
L = span(:,2)-span(:,1);
if (N<=0)||isempty(N)
    N=(round(max(L)/2)>50)*50+(round(max(L)/2)<=50)*round(max(L)/2);
end 
if (be<=0)||isempty(be)
    be=15/N;
end 
if (ro<-1)||isempty(ro)
    ro=10;
end 
if (d<0)||isempty(d)
    d=round(N/10);
end

% Demarrage du chronometre
tic;

% Initialisation de la population
[cand_popu,span,L,C]=cs_init(N,nvar,span);
if isempty(init)
	popu=cand_popu;
else
	popu=init;
end

ev_p=popu;
imag_popu = costfunc(popu);
ev_c=imag_popu;
k=1;
nbiter=1;

% Taux de lcs_mutation appliques aux clones
taux_mut_clones = lcs_clonage((ones(nvar,1)*exp(-ro*...
    linspace(1,0,N))),be,N);  % vecteur ligne de longueur N duplique en...
%                               nvar lignes puis clone

% Iterations
while continuer_lCS(ev_c,k,toc(),tol,itmax,durmax)
	% Clonage puis lcs_mutation suivie...
%     de l'extraction de la population trouvee
    [popu,imag_popu] = lcs_extraction(lcs_mutation(lcs_clonage(popu,be,N),...
        nvar,be,N,taux_mut_clones,span,C),popu,imag_popu,be,N,nvar);

	% Remplacement des "d" moins bons de popu actuelle par...
%     popu_sangneuf -> generation d'une nouvelle popu
	[popu,imag_popu] = lcs_forcer((L*ones(1,d)).*rand(nvar,d)+...
        (C*ones(1,d)),popu,imag_popu,N,d);
	
	% Enregistrement des meilleurs
    ev_p(:,:,k+1)=popu;
    if sum(typeopt=='min')==3
        ev_c(k+1,:) = imag_popu;
    elseif sum(typeopt=='max')==3
        ev_c(k+1,:) = -imag_popu;
    end

	nbiter=k;
	k=k+1;
end

best = popu;
cost = ev_c(nbiter+1,:);
dur=toc;
end

%fonctions appelees par lCS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [popu,span,L,C]=cs_init(N,nvar,span)
if size(span,1)~=nvar
    span=(ones(nvar,1)*[min(span(:,1)),max(span(:,2))]);
end
L = span(:,2)-span(:,1);
C = span(:,1);
popu = (L*ones(1,N)).*rand(nvar,N)+(C*ones(1,N));
end

%decide si l'optimisation doit continuer
%nb: a redefinir selon les besoins
function b=continuer_lCS(hist,i,t,seuil,imax,tmax)
%hist : vecteur historique de la performance des meilleurs individus
%i : scalaire, iteration courante
%t : scalaire, duree ecoulee depuis le debut de l'optimisation
%seuil : scalaire, seuil de convergence sur la fonction cout 
%imax : nombre maximal d'iterations autorise
%tmax : duree maximale du calcul
b=true;
if min(hist(size(hist,1),:))<seuil
    b=false;
end
if i>imax
    b=false;
end
if t>tmax
    b=false;
end
end

% Clonage d'une population, Remarque:la population en entree est...
% supposee triee;
% (N*floor(be*N)) (nombre total de clones) = N*ValEntiere(be*N)
function [popu_clone] = lcs_clonage (popu_select,be1,N1);
popu_clone = matrix((ones(floor(be1*N1),1)*matrix(popu_select',1,-1))...
    ,N1*floor(be1*N1),-1)';
end

% Mutation de la population
function [popu_mut] = lcs_mutation (popu_clones,nvar1,be1,N1,...
    taux_mut_clones1,span1,C1);
popu_mut = popu_clones.*(1 + (2*rand(nvar1,(N1*floor(be1*N1)))-1).*...
    taux_mut_clones1);
D=span1(:,2)*ones(1,(N1*floor(be1*N1)));
G=C1*ones(1,(N1*floor(be1*N1)));
popu_mut = (popu_mut>=D).*D+(popu_mut<=G).*G+((popu_mut<D)&...
    (popu_mut>G)).*popu_mut;
end

% Extraction des clones (peres-fils)
function [popu_nouvelle,imag_popu_clones_mut] = lcs_extraction (...
    popu_clones_mut,popu_ancienne,imag_popu_ancienne,be1,N1,nvar1);
imag_popu_clones_mut_ini = costfunc(popu_clones_mut);
for j=1:N1
    [tmpmin,temp] = min(imag_popu_clones_mut_ini(1,((j-1)*...
        floor(be1*N1))+(1:floor(be1*N1))),[],2);
    if imag_popu_ancienne(1,j)>tmpmin
        popu_nouvelle(1:nvar1,j)=popu_clones_mut(:,((j-1)*...
            floor(be1*N1))+temp(1));
        imag_popu_clones_mut(1,j)=imag_popu_clones_mut_ini(1,...
            ((j-1)*floor(be1*N1))+temp(1));
    else
        popu_nouvelle(1:nvar1,j)=popu_ancienne(:,j);
        imag_popu_clones_mut(1,j)=imag_popu_ancienne(1,j);
    end
end
end

% Remplacer les "d" moins bons de tab2 par une population aleatoire...
% contenue dans tab1, Remarque:tab2 est supposee triee
function [popu_nouvelle,imag_popu_nouvelle] = lcs_forcer (tab1,tab2,...
    imag_tab2,N1,d1);
if isempty(tab1)
	popu_nouvelle = tab2;
	imag_popu_nouvelle = imag_tab2;
else
    [imag_tab2_triee,permut] = sort(imag_tab2);
    popu_nouvelle = tab2(:,permut);
    popu_nouvelle = [popu_nouvelle(:,1:(N1-d1)),tab1(:,1:d1)];
    imag_popu_nouvelle = [imag_tab2_triee(1,1:(N1-d1)),costfunc(tab1(:,1:d1))];
    [permut_triee,permut_inv] = sort(permut);
    popu_nouvelle = popu_nouvelle(:,permut_inv);
    imag_popu_nouvelle = imag_popu_nouvelle(1,permut_inv);
end
end


