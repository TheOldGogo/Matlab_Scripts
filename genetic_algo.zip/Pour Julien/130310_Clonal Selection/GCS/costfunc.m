% Cost functions used by the 'gcs' algorithm
%
% Guillaume Plateau Feb. 23rd 2010
%            grplateau@lbl.gov
%            yguig2@yahoo.fr
% 
% --------------------------------------------------------------------
% Input parameters
% --------------------------------------------------------------------
% popu: matrix for which each column contains parameters of costfunc
%       each column is a cell, the matrix is the population of cells
% X:    x
% Y:    f(x) to be fitted
% tfct: type of costfunc (predefined ones: 1-6)
% argf: optional parameter if needed. In polynomial case, it is the order
%       of the polynom
% --------------------------------------------------------------------
% Output parameters
% --------------------------------------------------------------------
% z:    cost function, sum of mean square (can be changed if needed)
% --------------------------------------------------------------------
% 
% --------------------------------------------------------------------
% Example:
% Fitting function is g(x) = p1*x^2 + p2*log(x) +p3
% 
% popu will be filled of columns of [p1;p2;p3] to be tested
% 
% Under "Otherwise", you define g(x) ("longfct")
% over the matrix popu ("longV"), and the axis X ("longX"):
% 
% longfct=longV(1,:).*(longX.^2) + longV(2,:).*log(longX) + longV(3,:);
% --------------------------------------------------------------------


function z=costfunc(popu,X,Y,tfct,argf)
if ~isempty(popu)
    longV = matrix((ones(size(X,2),1)*matrix(popu',1,-1)),size(X,2)*...
        size(popu,2),-1)';
    longX = matrix(X'*ones(1,size(popu,2)),1,-1);
    longY = matrix(Y'*ones(1,size(popu,2)),1,-1);
    switch tfct
        case 1 % Gaussian
            longfct=longV(1,:)+longV(2,:).*exp((-1/2)*...
                (((longX-longV(3,:))./longV(4,:)).^2));
        case 2 % Linear
            longfct=longV(1,:)+longV(2,:).*longX;
        case 3 % Polynomial
            longfct=longV(1,:);
            for i=1:argf
                longfct=longfct+longV(i+1,:).*(longX.^i);
            end
        case 4 % Exponential
            longfct=longV(1,:)+longV(2,:).*exp(-longV(3,:).*...
                (longX-longV(4,:)));
        case 5 % Gate
            longfct=((longX>=longV(1,:))&(longX<longV(2,:))).*longV(3,:);
        case 6 % One root polynomial
            longfct=longV(1,:)+longV(2,:).*...
                ((longX-longV(3,:)).^longV(4,:));
        otherwise % special fit (define your own function here)
            longfct=0;
    end
    z = sum(matrix((longY-longfct).^2,size(Y,2),-1),1);
else
	z=[];
end



